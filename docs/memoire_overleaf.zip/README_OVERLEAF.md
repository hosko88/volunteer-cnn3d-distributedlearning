# Version Overleaf

Le fichier `memoire_complet_fr.tex` est autonome et peut être utilisé directement comme fichier principal dans Overleaf.

## Importation

1. Ouvrir Overleaf et créer un projet vide.
2. Téléverser `memoire_complet_fr.tex`.
3. Sélectionner ce fichier comme `Main document`.
4. Choisir le compilateur `pdfLaTeX`.
5. Compiler.

La bibliographie est intégrée avec `thebibliography` : aucune compilation BibTeX n'est nécessaire. Les figures principales sont produites avec TikZ, donc aucun fichier image externe n'est requis.

Avant le dépôt, remplacer les valeurs personnelles suivantes dans le préambule :

- `\\MATRICULE`
- `\\ENCADRANTDEUX`
- l'affiliation du second encadrant
- la section Remerciements

Les résultats marqués comme « à mesurer », « à exporter » ou « trace partielle disponible » doivent être remplacés par des valeurs provenant des exports expérimentaux avant la soutenance.
